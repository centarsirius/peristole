import os

print("PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing")

from import amp.py
from import geo_grav_td.py
from import lat_td.py
from import rot_td.py
