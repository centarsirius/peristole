from setuptools import setup, find_packages

setup(
    name='peristole',
    version='1.0.5',
    license="MIT",
    url='https://github.com/centarsirius/peristole',
    descriptions="PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing",
    packages=find_packages(),
    authors='Sachin Venkatesh, Gaurav Pundir'
)
