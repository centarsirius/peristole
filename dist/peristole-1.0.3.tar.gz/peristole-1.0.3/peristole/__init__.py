import os

print("PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing")

from peristole import amp.py
from peristole import geo_grav_td.py
from peristole import lat_td.py
from peristole import rot_td.py
