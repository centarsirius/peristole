import os

print("PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing")