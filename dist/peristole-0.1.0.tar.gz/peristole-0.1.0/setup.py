from setuptools import setup, find_packages

setup(
    name='peristole',
    version='0.1.0',
    license="MIT",
    url='https://github.com/centarsirius/peristole',
    descriptions="PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing",
    packages=find_packages(),
    authors='Sachin Venkatesh, Gaurava Pundir'
)
