import os

print("PERISTOLE : PackagE that geneRates tIme delay plotS due To gravitatiOnaL lEnsing")

import amp.py
import geo_grav_td.py
import lat_td.py
import rot_td.py
