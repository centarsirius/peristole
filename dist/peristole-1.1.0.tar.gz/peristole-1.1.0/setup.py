from setuptools import setup, find_packages

setup(
    name='peristole',
    version='1.1.0',
    license="MIT",
    url='https://github.com/centarsirius/peristole',
    descriptions="PERISTOLE : PackagE that geneRates tIme delay plotS caused by graviTatiOnaL lEnsing",
    packages=find_packages(),
    authors='Sachin Venkatesh, Gaurav Pundir'
)
