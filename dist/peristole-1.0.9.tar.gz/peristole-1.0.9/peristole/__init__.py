import os

print("PERISTOLE : PackagE that geneRates tIme delay plotS caused by graviTatiOnaL lEnsing")

from .amp import *
from .geom_td import *
from .grav_td import *
from .rot_td import *
from .lat_td import  *
from .pulsar_class import *